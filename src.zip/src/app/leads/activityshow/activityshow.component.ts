import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activityshow',
  templateUrl: './activityshow.component.html',
  styleUrls: ['./activityshow.component.scss']
})
export class ActivityshowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
