export interface Login {
    userName: string;
    password: string;
    FCM: string;
    p_id?: number;
  }


  export interface Target {
    amount: string;
    monthYear: string;
    SalesPersonCode: string;
    CreatedDate: string;
    id?: number;
  }