import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-language',
  templateUrl: './master-language.component.html',
  styleUrls: ['./master-language.component.scss']
})
export class MasterLanguageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
